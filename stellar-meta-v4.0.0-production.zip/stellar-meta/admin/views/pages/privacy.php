<?php
defined( 'ABSPATH' ) || exit;
if ( ! current_user_can( 'manage_woocommerce' ) ) { wp_die( esc_html__( 'You do not have permission to view this page.', 'stellar-meta' ) ); }
/* privacy.php */
defined( 'ABSPATH' ) || exit;
$s = Stellar_Meta_Settings::instance();
?>
<div class="sm-header">
  <div class="sm-header-left">
    <div class="sm-logo">S</div>
    <div>
      <div class="sm-header-title">Privacy & Compliance</div>
      <div class="sm-header-sub">GDPR · CCPA · Consent Mode · Cookieless Tracking</div>
    </div>
  </div>
  <div class="sm-header-right">
    <?php if($s->is_gdpr_mode()): ?>
    <span class="sm-badge sm-badge-green"><span class="sm-dot"></span> GDPR Active</span>
    <?php endif; ?>
    <?php if($s->is_ccpa_enabled()): ?>
    <span class="sm-badge sm-badge-blue"><span class="sm-dot"></span> CCPA Active</span>
    <?php endif; ?>
  </div>
</div>

<div class="sm-content">

  <div class="sm-grid-4" style="margin-bottom:20px">
    <?php $metrics = [
      [ 'GDPR Mode',      $s->is_gdpr_mode()     ? 'Active' : 'Off', $s->is_gdpr_mode()     ? 'var(--sm-green)' : 'var(--sm-red)',  'Blocks pixels until consent' ],
      [ 'CCPA Support',   $s->is_ccpa_enabled()  ? 'Active' : 'Off', $s->is_ccpa_enabled()  ? 'var(--sm-green)' : 'var(--sm-muted)', 'Respects opt-out signals' ],
      [ 'CAPI Fallback',  $s->is_capi_enabled()  ? 'Active' : 'Off', $s->is_capi_enabled()  ? 'var(--sm-blue)'  : 'var(--sm-muted)', 'Server-side when pixel blocked' ],
      [ 'PII Hashing',    $s->is_pii_hashing()   ? 'SHA-256' : 'Off',$s->is_pii_hashing()   ? 'var(--sm-gold2)' : 'var(--sm-red)',   'Hashes all personal data' ],
    ];
    foreach($metrics as [$label,$val,$color,$desc]): ?>
    <div class="sm-metric" style="border-top-color:<?php echo $color;?>">
      <div class="sm-metric-label"><?php echo esc_html($label);?></div>
      <div class="sm-metric-value" style="font-size:18px;color:<?php echo $color;?>"><?php echo esc_html($val);?></div>
      <div class="sm-metric-delta flat"><?php echo esc_html($desc);?></div>
    </div>
    <?php endforeach;?>
  </div>

  <div class="sm-grid-2">
    <div class="sm-card">
      <div class="sm-card-header"><span class="sm-card-title">Privacy Controls</span>
        <a href="<?php echo esc_url(admin_url('admin.php?page=stellar-meta-settings'));?>" class="sm-card-action">Edit in Settings →</a>
      </div>
      <div class="sm-card-body">
        <?php $toggles = [
          ['GDPR Consent Gate',     'Blocks ALL tracking until visitor grants consent.',      $s->is_gdpr_mode()],
          ['CCPA Opt-Out Support',  'Honours GPC / Do Not Sell signals automatically.',       $s->is_ccpa_enabled()],
          ['Cookieless CAPI',       'Server-side events fire even when cookies are blocked.', $s->is_capi_enabled()],
          ['PII SHA-256 Hashing',   'Hashes email, phone, name, zip before sending to Meta.',$s->is_pii_hashing()],
          ['Lazy-Load Pixel',       'Pixel fires after first user gesture — improves Core Web Vitals.', $s->is_lazy_pixel()],
          ['Script Deferral',       'Non-critical tracking scripts load after LCP.',           $s->is_script_deferral()],
        ];
        foreach($toggles as [$label,$desc,$on]): ?>
        <div class="sm-toggle-row">
          <div class="sm-toggle-info">
            <div class="sm-toggle-label"><?php echo esc_html($label);?></div>
            <div class="sm-toggle-desc"><?php echo esc_html($desc);?></div>
          </div>
          <span class="sm-badge <?php echo $on ? 'sm-badge-green' : 'sm-badge-muted';?>"><?php echo $on ? 'ON' : 'OFF';?></span>
        </div>
        <?php endforeach;?>
      </div>
    </div>

    <div class="sm-card">
      <div class="sm-card-header"><span class="sm-card-title">Consent Mode Integration</span></div>
      <div class="sm-card-body">
        <div class="sm-notice sm-notice-info" style="margin-bottom:16px">
          Stellar Meta implements Google Consent Mode v2 and Meta Consent Mode. Events are gated by consent status and routed to server-side CAPI as a privacy-preserving fallback.
        </div>
        <div style="font-size:11px;text-transform:uppercase;letter-spacing:.08em;color:var(--sm-muted);font-family:'DM Mono',monospace;margin-bottom:10px">Consent API Endpoint</div>
        <div class="sm-code"><?php echo esc_html(rest_url('stellar-meta/v1/consent'));?></div>
        <div style="margin-top:14px;font-size:11px;text-transform:uppercase;letter-spacing:.08em;color:var(--sm-muted);font-family:'DM Mono',monospace;margin-bottom:10px">CAPI Bridge Endpoint</div>
        <div class="sm-code"><?php echo esc_html(rest_url('stellar-meta/v1/track'));?></div>
        <div class="sm-notice sm-notice-success" style="margin-top:14px">
          ✓ iOS 14.5+ compatible — CAPI delivers purchase signals without relying on browser cookies or pixel.
        </div>
      </div>
    </div>
  </div>

</div>
